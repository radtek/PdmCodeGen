﻿        /// <summary>
        /// {ColName}
        /// </summary>
        public {ColDataType} {ColCode} { get; set; }